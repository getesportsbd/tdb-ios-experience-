# TDB iOS Experience v1.1 — Android launcher starter

A phone-buildable Android Studio/Gradle project with an iOS-inspired launcher interface.

## What works in this build
- Can be selected as the Android Home app (default launcher).
- Shows an App Library populated from launchable apps installed on the phone.
- Search/filter apps and tap to launch them.
- Control Center-style panel with shortcuts to Android Wi-Fi, Bluetooth, display, sound, wallpaper and settings screens.
- No dangerous permissions are requested.

## What is not included / Android limitations
- This does not convert Android into iOS.
- Dynamic Island is a visual imitation only.
- Android's real notification shade and secure lock screen are not replaced.
- Wi-Fi/Bluetooth controls open Android Settings; ordinary apps cannot freely toggle these on modern Android.
- iOS widgets, Apple services, iMessage, Face ID, AirDrop, and Apple's proprietary system UI cannot be recreated as native iOS features.
- Icons currently use generic glyphs rather than reading each installed app's actual icon.

## Build APK using GitHub Actions (no PC)
1. Download and extract this ZIP on your phone.
2. Sign in at https://github.com and create a **public or private** repository named `tdb-ios-experience`.
3. Upload the extracted project contents to the repository root. Make sure `app`, `.github`, `build.gradle`, and `settings.gradle` are at the root (not inside an extra nested folder).
4. Open the repository's **Actions** tab. If prompted, enable workflows.
5. Select **Build TDB iOS Experience APK** and tap **Run workflow**. Or make any commit to `main` to trigger it.
6. Wait for the workflow to turn green. Open that successful run.
7. Scroll to **Artifacts**, tap `TDB-iOS-Experience-debug-apk`, and download it.
8. Open the downloaded ZIP in your phone's Files app, extract `app-debug.apk`, then tap the APK to install.
9. If Android asks, allow your browser or Files app to install unknown apps. Only install the APK you built from your own repository.

## Set as default Home app
After installation, press the phone's Home button/gesture. If Android asks which Home app to use, select **TDB iOS Experience** and choose **Always**. You can change it later in Android Settings > Apps > Default apps > Home app.

## Requirements
GitHub Actions builds on a hosted Ubuntu runner with JDK 17, Gradle 8.7 and Android SDK.
