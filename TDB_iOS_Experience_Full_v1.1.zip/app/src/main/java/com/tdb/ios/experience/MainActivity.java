package com.tdb.ios.experience;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ApplicationInfo;
import android.net.Uri;
import android.provider.Settings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private WebView web;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(232,241,255));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(232,241,255));
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(
                android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR |
                android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        web = new WebView(this);
        web.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.addJavascriptInterface(new PhoneBridge(), "TDB");
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private class PhoneBridge {
        @JavascriptInterface public String getApps() {
            JSONArray arr = new JSONArray();
            Intent intent = new Intent(Intent.ACTION_MAIN, null);
            intent.addCategory(Intent.CATEGORY_LAUNCHER);
            PackageManager pm = getPackageManager();
            List<ResolveInfo> apps = pm.queryIntentActivities(intent, 0);
            Collections.sort(apps, new Comparator<ResolveInfo>() {
                public int compare(ResolveInfo a, ResolveInfo b) {
                    return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString());
                }
            });
            for (ResolveInfo ri : apps) {
                try {
                    JSONObject o = new JSONObject();
                    o.put("name", ri.loadLabel(pm).toString());
                    o.put("pkg", ri.activityInfo.packageName);
                    o.put("icon", "");
                    arr.put(o);
                } catch (Exception ignored) {}
            }
            return arr.toString();
        }

        @JavascriptInterface public void launchApp(String pkg) {
            runOnUiThread(() -> {
                try {
                    Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
                    if (launch != null) startActivity(launch);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface public void openSettings(String type) {
            runOnUiThread(() -> {
                try {
                    Intent i;
                    if ("wifi".equals(type)) i = new Intent(Settings.ACTION_WIFI_SETTINGS);
                    else if ("bluetooth".equals(type)) i = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                    else if ("display".equals(type)) i = new Intent(Settings.ACTION_DISPLAY_SETTINGS);
                    else if ("sound".equals(type)) i = new Intent(Settings.ACTION_SOUND_SETTINGS);
                    else if ("apps".equals(type)) i = new Intent(Settings.ACTION_APPLICATION_SETTINGS);
                    else if ("wallpaper".equals(type)) i = new Intent(Intent.ACTION_SET_WALLPAPER);
                    else i = new Intent(Settings.ACTION_SETTINGS);
                    startActivity(i);
                } catch (Exception ignored) {}
            });
        }

        @JavascriptInterface public void openNotificationSettings() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)); }
                catch (Exception ignored) {}
            });
        }

        @JavascriptInterface public void openAppDetails() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    i.setData(Uri.parse("package:" + getPackageName()));
                    startActivity(i);
                } catch (Exception ignored) {}
            });
        }
    }

    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("showHome()", null);
        else super.onBackPressed();
    }
}
